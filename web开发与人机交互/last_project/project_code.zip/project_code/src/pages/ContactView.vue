<template>
    <div class="contact">
        <div class="banner">
            <!-- 黑色修饰线 -->
            <hr />
            <form class="content">
                <!-- 标题 -->
                <div class="title">
                    <h3>京东首页-用户体验调查</h3>
                </div>
                <!-- 感谢语 -->
                <div class="words">
                    <p>尊敬的用户:</p>
                    <p>
                        您好！为了给您提供更好的产品和服务，我们希望收集您使用<span>京东首页</span>时的看法或建议。对您的配合和支持表示衷心感谢！
                    </p>
                </div>
                <!-- 问卷   -->
                <div class="survey">
                    <div class="ques1 ques">
                        <div class="text">
                            <span class="red">* </span>
                            <span>1.</span>
                            <div>
                                如果您在使用京东首页时，有什么好或不好的地方，请在此留言！我们会关注您的反馈，不断优化产品，为您提供更好的服务！
                            </div>
                        </div>
                        <div class="bottom">
                            <textarea></textarea>
                        </div>
                    </div>
                    <div class="ques2 ques">
                        <div class="text">
                            <span>2.&nbsp;</span>
                            <div>为了便于我们核查问题，可上传遇到问题的截图。</div>
                        </div>
                        <div class="bottom">
                            <button><i class="iconfont icon-shangchuan"></i>上传图片</button>
                            <span>限制大小20M</span>
                        </div>
                    </div>
                    <div class="ques3 ques">
                        <div class="text">
                            <span>3.&nbsp;</span>
                            <div>
                                为了方便我们与您联系，可填写您的手机号。（选填，信息仅作为内部资料绝不外泄）
                            </div>
                        </div>
                        <div class="bottom">
                            <textarea></textarea>
                        </div>
                    </div>
                </div>
                <!-- 提交按钮 -->
                <button type="submit" class="btn btn-primary">提交</button>
            </form>
        </div>
    </div>
</template>

<script>
export default {
    mounted() {
        let body = document.querySelector("body")
        body.style.backgroundColor = "#eee"
        let title = document.querySelector("html head title")
        title.innerHTML = "京东-用户反馈"
    }
}
</script>

<style scoped>
@import url(../style/contact.css);
</style>