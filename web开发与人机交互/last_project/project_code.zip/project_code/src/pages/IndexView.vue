<template>
    <div>
        <!-- 最顶部栏 -->
        <div class="top">
            <div class="banner">
                <!-- 左边部分 -->
                <div class="t_left">
                    <i class="iconfont icon-dingwei"> </i><a href="#">送至：北京</a>
                </div>
                <!-- 右边部分 -->
                <div class="t_right">
                    <ul>
                        <li>
                            <a href="/login">你好，请登录</a>
                            <span><a href="/register">免费注册</a></span>
                        </li>
                        <div class="line"></div>
                        <li>
                            <a target="_blank" href="https://order.jd.com/center/list.action">我的订单</a>
                        </li>
                        <div class="line"></div>
                        <li>
                            <a target="_blank" href="/personal">个人中心<i class="iconfont icon-xiala"></i></a>
                        </li>
                        <div class="line"></div>
                        <li>
                            <a href="#">京东会员</a>
                        </li>
                        <div class="line"></div>
                        <li>
                            <a target="_blank" href="https://b.jd.com/">企业采购</a>
                        </li>
                        <div class="line"></div>
                        <li>
                            <i class="iconfont icon-shouji"></i>
                            <a href="#">手机京东<i class="iconfont icon-xiala"></i></a>
                        </li>
                        <div class="line"></div>
                        <li>
                            <a href="#">关注京东<i class="iconfont icon-xiala"></i></a>
                        </li>
                        <div class="line"></div>
                        <li>
                            <a href="./contact" target="_blank">客户服务<i class="iconfont icon-xiala"></i></a>
                        </li>
                        <div class="line"></div>
                        <li>
                            <a href="#">网站导航<i class="iconfont icon-xiala"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <!-- 广告栏 -->
        <div class="advert">
            <img src="./images/di2ceng.jpg" alt="" />
        </div>
        <!-- 头部栏 -->
        <div class="header">
            <div class="banner">
                <div class="h_left logo">
                    <img src="./images/di3ceng.png" alt="" />
                </div>
                <div class="h_right">
                    <div class="search">
                        <!-- 搜索栏和按钮 -->
                        <div>
                            <el-autocomplete class="inline-input" v-model="state" :fetch-suggestions="querySearch"
                                placeholder="请输入内容"></el-autocomplete>
                            <button @click="toGoodurl">搜索</button>
                        </div>
                        <!-- 购物车 -->
                        <a class="cart position-relative" href="/cart">
                            <img src="./images/di3cenggouwuche.png" alt="" />
                            我的购物车
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                {{ this.cart_num > 99 ? "99+" : this.cart_num }}
                                <span class="visually-hidden">unread messages</span>
                            </span>
                        </a>
                    </div>
                    <!-- 热门商品关键字导航 -->
                    <div class="hotinfo">
                        <ul>
                            <li>
                                <a target="_blank"
                                    href="https://search.jd.com/Search?keyword=iphoneSE&enc=utf-8&wq=iphoneSE&pvid=596ffaf61f0547d5b63539e7b40ddde5">iphoneSE</a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://plus.jd.com/index?flow_system=appicon&flow_entrance=appicon11&flow_channel=pc">满千减百</a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://search.jd.com/Search?keyword=%E6%98%A5%E5%AD%A3%E7%BE%8E%E5%8C%85&enc=utf-8&wq=%E6%98%A5%E5%AD%A3%E7%BE%8E%E5%8C%85&pvid=3c8f1832dd284679aa02f9bf2995afdb">春季美包</a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://search.jd.com/Search?keyword=%E9%83%91%E6%B8%8A%E6%B4%81&enc=utf-8&wq=%E9%83%91%E6%B8%8A%E6%B4%81&pvid=7ac6025d12b14668b58ece055af63a12">郑渊洁</a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://pro.jd.com/mall/active/2f1B2S2mXyDsWcitZza9QoZnfxjM/index.html?babelChannel=ttt32">1元专享</a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://search.jd.com/Search?keyword=%E6%A3%89%E9%BA%BB%E8%BF%9E%E8%A1%A3%E8%A3%99&enc=utf-8&wq=%E6%A3%89%E9%BA%BB%E8%BF%9E%E8%A1%A3%E8%A3%99&pvid=3044d3adf07841f78f0f7c20c9fecd37">棉麻连衣裙</a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://search.jd.com/Search?keyword=%E6%82%A6%E8%AF%97%E9%A3%8E%E5%90%9F&enc=utf-8&wq=%E6%82%A6%E8%AF%97%E9%A3%8E%E5%90%9F&pvid=9c98f12f84e44f5dbdc55b2178e8014d">悦诗风吟</a>
                            </li>
                            <li>
                                <a target="_blank" href="https://miaosha.jd.com/">99爆款</a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://search.jd.com/Search?keyword=%E8%8A%B1%E6%B4%92%E5%96%B7%E5%A4%B4&enc=utf-8&wq=%E8%8A%B1%E6%B4%92%E5%96%B7%E5%A4%B4&pvid=225c5f941b6a4afc8c5214fc9a7c65ba">花洒喷头</a>
                            </li>
                        </ul>
                    </div>
                    <div class="keyword">
                        <ul>
                            <li>
                                <a target="_blank"
                                    href="https://pro.jd.com/mall/active/2aRK8YxJGhgc1gEnXLJPhT6KodXd/index.html?babelChannel=ttt3">服装城</a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://prodev.jd.com/mall/active/2kmaPNrGDNYo1LKwYtRoaSmsgbj6/index.html">美妆馆</a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://pro.jd.com/mall/active/36yPbWm4JqFrmTgABydz6GkWNkca/index.html">超市</a>
                            </li>
                            <li><a target="_blank" href="https://www.jd.hk/">全球购</a></li>
                            <li>
                                <a target="_blank" href="/flashSale">秒杀</a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://pro.jd.com/mall/active/41f9ic44VcMRxNRtT8JWsfr8Chnn/index.html?babelChannel=ttt24">团购</a>
                            </li>
                            <li>
                                <a target="_blank" href="https://auction.jd.com/sifa.html">拍卖</a>
                            </li>
                            <li><a target="_blank" href="https://jr.jd.com/">金融</a></li>
                        </ul>
                    </div>
                </div>
                <!-- 京东秒杀 -->
                <a target="_blank" href="/flashSale" class="flash">
                    <h5>京东秒杀</h5>
                    <p><span>{{ currentHour }}:00</span>点场 距结束</p>
                    <h5>
                        <span>{{ lastHour }}</span>:<span>{{ lastMinutes }}</span>:<span>{{ lastSeconds }}</span>
                    </h5>
                </a>
            </div>
        </div>
        <!-- 内容模块 -->
        <div class="content">
            <div class="banner">
                <!-- 分类导航 -->
                <div class="classify">
                    <ul>
                        <li>
                            <a target="_blank"
                                href="https://pro.jd.com/mall/active/2vx2zyXR2KhRouYS6LrSEdnLF1P5/index.html">家用电器</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank"
                                href="https://search.jd.com/Search?keyword=%E6%89%8B%E6%9C%BA&enc=utf-8&wq=%E6%89%8B%E6%9C%BA&pvid=8858151673f941e9b1a4d2c7214b2b52">手机</a>、<a
                                target="_blank"
                                href="https://search.jd.com/Search?keyword=%E6%95%B0%E7%A0%81&enc=utf-8&wq=%E6%95%B0%E7%A0%81&pvid=34b0fcf7ed434840a74c057bc97be346">数码</a>、<a
                                href="https://mobile.jd.com/index.do">京东通信</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank"
                                href="https://prodev.jd.com/mall/active/31XPWPTonxJ9e5YoQ85HS7z8XNYQ/index.html?babelChannel=ttt40">电脑</a>、<a
                                target="_blank"
                                href="https://prodev.jd.com/mall/active/3Sn1bAr73mUmVRFTHwgi8emZmd3Y/index.html?babelChannel=ttt3">办公</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank" href="https://list.jd.com/list.html?cat=1620">家居</a>、<a target="_blank"
                                href="https://search.jd.com/Search?keyword=%E5%AE%B6%E5%85%B7&enc=utf-8&pvid=1c58265e1904499a9c1d9c7847b7b962">家具</a>、<a
                                target="_blank"
                                href="https://search.jd.com/Search?keyword=%E5%AE%89%E8%A3%85&enc=utf-8&wq=%E5%AE%89%E8%A3%85&pvid=97bb21465c894defaccfc1f197896150">家装</a>、<a
                                target="_blank"
                                href="https://search.jd.com/Search?keyword=%E5%8E%A8%E5%85%B7&enc=utf-8&wq=%E5%8E%A8%E5%85%B7&pvid=7bdf296458744f4d8d17be5fbdaed59a">厨具</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank"
                                href="https://prodev.jd.com/mall/active/32EphPL81Mb6FD4qLCTtYmd31YXr/index.html">男装</a>、<a
                                target="_blank" href="./womenclothing">女装</a>、<a target="_blank"
                                href="https://pro.jd.com/mall/active/4PgpL1xqPSW1sVXCJ3xopDbB1f69/index.html">内衣</a>、<a
                                target="_blank"
                                href="https://pro.jd.com/mall/active/22DpAdd48C4fU3cBRkeYSM87WhWV/index.html?babelChannel=ttt148">珠宝</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank"
                                href="https://prodev.jd.com/mall/active/2kmaPNrGDNYo1LKwYtRoaSmsgbj6/index.html">个护化妆</a>、<a
                                target="_blank"
                                href="https://search.jd.com/Search?keyword=%E4%B8%AA%E6%8A%A4%E6%B8%85%E6%B4%81&enc=utf-8&wq=%E4%B8%AA%E6%8A%A4%E6%B8%85%E6%B4%81&pvid=261b201c58c643d88b3722d66158dd67">清洁用品</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank"
                                href="https://prodev.jd.com/mall/active/4RXyb1W4Y986LJW8ToqMK14BdTD/index.html?babelChannel=ttt47">鞋靴</a>、<a
                                target="_blank"
                                href="https://prodev.jd.com/mall/active/ZrH7gGAcEkY2gH8wXqyAPoQgk6t/index.html?babelChannel=ttt4">箱包</a>、<a
                                target="_blank"
                                href="https://pro.jd.com/mall/active/2BcJPCVVzMEtMUynXkPscCSsx68W/index.html">钟表</a>、<a
                                target="_blank"
                                href="https://pro.jd.com/mall/active/22DpAdd48C4fU3cBRkeYSM87WhWV/index.html?babelChannel=ttt148">奢侈品</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank"
                                href="https://pro.jd.com/mall/active/2MG8bJwgHvAqAZ9PamfCp3pDuthL/index.html">运动户外</a><a
                                href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank"
                                href="https://pro.jd.com/mall/active/3nyhiLnZVA73a253VHck3B6MCYY/index.html?babelChannel=ttt2">汽车</a>、<a
                                target="_blank"
                                href="https://pro.jd.com/mall/active/4JruAPmSpktmTDvWthZqyWqBgP5e/index.html?babelChannel=ttt2">汽车用品</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank"
                                href="https://search.jd.com/Search?keyword=%E6%AF%8D%E5%A9%B4&enc=utf-8&wq=%E6%AF%8D%E5%A9%B4&pvid=3e86f063795740d594b1bb1187e02063">母婴</a>、<a
                                target="_blank"
                                href="https://search.jd.com/Search?keyword=%E7%8E%A9%E5%85%B7%E4%B9%90%E5%99%A8&enc=utf-8&wq=%E7%8E%A9%E5%85%B7%E4%B9%90%E5%99%A8&pvid=6acae74f0ea34c6a8db6b5563f1a24d1">玩具乐器</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank"
                                href="https://search.jd.com/Search?keyword=%E9%A3%9F%E5%93%81&enc=utf-8&wq=%E9%A3%9F%E5%93%81&pvid=b22bb1ad1cb045aa989753d21f73c228">食品</a>、<a
                                target="_blank"
                                href="https://search.jd.com/Search?keyword=%E4%B8%AD%E5%A4%96%E5%90%8D%E9%85%92&enc=utf-8&wq=%E4%B8%AD%E5%A4%96%E5%90%8D%E9%85%92&pvid=16e1724bdc294613b5c43df42878baba">酒类</a>、<a
                                target="_blank" href="https://fresh.jd.com/">生鲜</a>、<a target="_blank"
                                href="https://pro.jd.com/mall/active/41YdRWconKueXwVVnLLM6YY4x4wU/index.html">特产</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank" href="https://health.jd.com/">营养保健</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank"
                                href="https://pro.jd.com/mall/active/3sAaxodHF7kfo3s95cjxo2UZUxu2/index.html">图书</a>、<a
                                target="_blank"
                                href="https://pro.jd.com/mall/active/2TxxbZnqAm7M8tkDpTN3VJNtoSKo/index.html">音像</a>、<a
                                target="_blank" href="https://e.jd.com/">电子书</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank"
                                href="https://plogin.m.jd.com/login/login?appid=100&wxautologin=false&returnurl=https%3A%2F%2Fcaipiao.m.jd.com%2F%3Fnull">彩票</a>、<a
                                target="_blank"
                                href="https://pro.jd.com/mall/active/zMyuWCEMidq8GZQjgxwm4G8LRC7/index.html">旅行</a>、<a
                                target="_blank" href="https://chongzhi.jd.com/">充值</a>、<a target="_blank"
                                href="https://train.jd.com/">票务</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                        <li>
                            <a target="_blank" href="https://www.jdpay.com/home/">理财</a>、<a target="_blank"
                                href="https://qyjr.jd.com/">众筹</a>、<a target="_blank" href="https://jr.jd.com/">白条</a>、<a
                                target="_blank"
                                href="https://pro.jd.com/mall/active/2bgLe2uLsTUb3MmuvRxmiA2vP38J/index.html?bxFromId=JDAPP&bxplace=bxpdpcsm">保险</a>
                            <a href=""><i class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                        </li>
                    </ul>
                </div>
                <!-- 轮播图 -->
                <div class="pic">
                    <div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide-to="0"
                                class="active" aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide-to="1"
                                aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide-to="2"
                                aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="./images/di5ceng.jpg" class="d-block w-100" alt="..." />
                            </div>
                            <div class="carousel-item">
                                <img src="./images/di5ceng2.jpg" class="d-block w-100" alt="..." />
                            </div>
                            <div class="carousel-item">
                                <img src="./images/di5ceng3.jpg" class="d-block w-100" alt="..." />
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
                <!-- 右侧板块 -->
                <div class="c_right">
                    <div class="report">
                        <dl>
                            <dt>
                                京东快报<a href="./news" target="_blank">更多<i
                                        class="iconfont icon-xiayiyeqianjinchakangengduo"></i></a>
                            </dt>
                            <dd>
                                <a href=""><b>[特惠]</b>陪着爸妈去出游 低至9.9</a>
                            </dd>
                            <dd>
                                <a href=""><b>[公告]</b>地方特产馆助力初春农产品上行</a>
                            </dd>
                            <dd>
                                <a href=""><b>[特惠]</b>冰洗好货盛宴，现金券免费领</a>
                            </dd>
                            <dd>
                                <a href=""><b>[公告]</b>京东生鲜“鲜”享初夏</a>
                            </dd>
                            <dd>
                                <a href=""><b>[特惠]</b>内衣尚新季自营买二免一</a>
                            </dd>
                        </dl>
                    </div>
                    <div class="middle_list">
                        <ul>
                            <li>
                                <a target="_blank" href="https://chongzhi.jd.com/"><img src="./images/di5cengbiaoge1.png"
                                        alt="" /><span>话费</span></a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://pro.jd.com/mall/active/phs5vyWsMWvtHP7woWyvBdrhqpf/index.html"><img
                                        src="./images/di5cengbiaoge2.png" alt="" /><span>机票</span></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://movie.jd.com/index.html#/"><img
                                        src="./images/di5cengbiaoge3.png" alt="" /><span>电影票</span></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://ylc.m.jd.com/ylc/ylcp?ext=2066"><img
                                        src="./images/di5cengbiaoge4.png" alt="" /><span>游戏</span></a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://plogin.m.jd.com/login/login?appid=100&wxautologin=false&returnurl=https%3A%2F%2Fcaipiao.m.jd.com%2F%3Fnull"><img
                                        src="./images/di5cengbiaoge5.png" alt="" /><span>彩票</span></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://b.jd.com/"><img src="./images/di5cengbiaoge6.png"
                                        alt="" /><span>团购</span></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://hotel.jd.com/"><img src="./images/di5cengbiaoge7.png"
                                        alt="" /><span>酒店</span></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://train.jd.com/"><img src="./images/di5cengbiaoge8.png"
                                        alt="" /><span>火车票</span></a>
                            </li>
                            <li>
                                <a target="_blank"
                                    href="https://biz.jd.com/login/binding/binding.do?return=aHR0cDovL2N6LmpkLmNvbS9sYXlJbmRleC5odG1s&show=jdpin&from=qiye&registerType=quick"><img
                                        src="./images/di5cengbiaoge9.png" alt="" /><span>众筹</span></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://jr.jd.com/"><img src="./images/di5cengbiaoge10.png"
                                        alt="" /><span>理财</span></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://o.jd.com/"><img src="./images/di5cengbiaoge11.png"
                                        alt="" /><span>礼品卡</span></a>
                            </li>
                            <li>
                                <a target="_blank" href="https://jr.jd.com/"><img src="./images/di5cengbiaoge12.png"
                                        alt="" /><span>白条</span></a>
                            </li>
                        </ul>
                    </div>
                    <div class="small_advert">
                        <img src="./images/di5cengyou.jpg" alt="" />
                    </div>
                </div>
            </div>
        </div>
        <!-- 今日推荐 -->
        <div class="recommend">
            <div class="banner">
                <ul>
                    <li>
                        <a href="./recommendation" target="_blank"><img src="./images/di6ceng1.png" alt="" /></a>
                    </li>
                    <li>
                        <a target="_blank" href="https://www.jd.hk/"><img src="./images/di6ceng2.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a target="_blank"
                            href="https://search.jd.com/Search?keyword=ipad%20mini2&enc=utf-8&wq=ipad%20mini2&pvid=25b3277bf59d404996ffba4d50932a42"><img
                                src="./images/di6ceng3.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a target="_blank"
                            href="https://pro.jd.com/mall/active/2aRK8YxJGhgc1gEnXLJPhT6KodXd/index.html?babelChannel=ttt3"><img
                                src="./images/di6ceng4.jpg" alt="" /></a>
                    </li>
                    <li>
                        <a target="_blank"
                            href="https://search.jd.com/Search?keyword=iPhoneSE&enc=utf-8&wq=iPhoneSE&pvid=328b44602f984e3490a38c16caf77723"><img
                                src="./images/di6ceng5.jpg" alt="" /></a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- 底部版权栏 -->
        <div class="footer">
            <div class="banner">
                <img src="./images/copyright.png" alt="" />
                <p class="mod_copyright_links">
                    <a href="//about.jd.com" target="_blank" rel="noopener noreferrer">关于我们</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//about.jd.com/contact" target="_blank" rel="noopener noreferrer">联系我们</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//help.jd.com/user/custom.html" target="_blank" rel="noopener noreferrer">联系客服</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//lai.jd.com" target="_blank" rel="noopener noreferrer">合作招商</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//helpcenter.jd.com/venderportal/index.html" target="_blank" rel="noopener noreferrer">商家帮助</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//jzt.jd.com" target="_blank" rel="noopener noreferrer">营销中心</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//app.jd.com/" target="_blank" rel="noopener noreferrer">手机京东</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//club.jd.com/links.aspx" target="_blank" rel="noopener noreferrer">友情链接</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//union.jd.com/index" target="_blank" rel="noopener noreferrer">销售联盟</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//pro.jd.com/mall/active/3WA2zN8wkwc9fL9TxAJXHh5Nj79u/index.html" target="_blank"
                        rel="noopener noreferrer">京东社区</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//pro.jd.com/mall/active/3TF25tMdrnURET8Ez1cW9hzfg3Jt/index.html" target="_blank"
                        rel="noopener noreferrer">风险监测</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//pro.jd.com/mall/active/2udA8Qxf3A54dVVseY5CdUMSgQPs/index.html" target="_blank"
                        rel="noopener noreferrer">质量公告</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//about.jd.com/privacy/" target="_blank" rel="noopener noreferrer">隐私政策</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//gongyi.jd.com" target="_blank" rel="noopener noreferrer">京东公益</a>
                    <span class="mod_copyright_split">|</span>
                    <a href="//corporate.jd.com" target="_blank" rel="noopener noreferrer">Media & IR</a>
                </p>
                <img src="./images/copyright2.png" alt="" />
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            restaurants: [],
            state: '', // 输入框的内容
            cart_num: 3,
            currentPeriod: '20:00',
            currentHour: 0,
            nextPeriod: '',
            lastHour: 0,
            lastMinutes: 0,
            lastSeconds: 0
        }
    },
    methods: {
        toGoodurl() {
            location.href = "https://search.jd.com/Search?keyword=" + this.state;
        },
        querySearch(queryString, cb) {
            var restaurants = this.restaurants;
            var results = queryString ? restaurants.filter(this.createFilter(queryString)) : restaurants;
            // 调用 callback 返回建议列表的数据
            cb(results);
        },
        createFilter(queryString) {
            return (restaurant) => {
                return (restaurant.value.toLowerCase().indexOf(queryString.toLowerCase()) >= 0);
            };
        },
        loadAll() {
            return [
                { "value": "iphone15" },
                { "value": "拯救者" },
                { "value": "三体" },
                { "value": "牛肉" },
                { "value": "初音未来" },
                { "value": "贡茶" },
                { "value": "猪肉" },
                { "value": "牛筋丸" },
                { "value": "苹果" },
                { "value": "面包" },
                { "value": "牛奶" },
                { "value": "奥利奥" },
                { "value": "士力架" },
                { "value": "德芙" },
                { "value": "3090ti" },
                { "value": "iPhone14Pro" },
                { "value": "快乐柠檬" },
                { "value": "cafe" },
                { "value": "可口可乐" },
                { "value": "百事可乐" },
                { "value": "雪碧" },
                { "value": "炫迈" },
                { "value": "熊博士" },
                { "value": "查理九世" }

            ];
        },
        getTime() {
            //获取当前是哪一个秒杀时间段，并转成数字格式
            let currentIndex = +localStorage.getItem("currentIndex");
            if (currentIndex === 0) {
                this.currentPeriod = new Date().setHours(0, 0, 0, 0);
                this.nextPeriod = new Date().setHours(12, 0, 0, 0);
            }
            else if (currentIndex === 1) {
                this.currentPeriod = new Date().setHours(12, 0, 0, 0);
                this.nextPeriod = new Date().setHours(15, 0, 0, 0);
            }
            else if (currentIndex === 2) {
                this.currentPeriod = new Date().setHours(15, 0, 0, 0);
                this.nextPeriod = new Date().setHours(18, 0, 0, 0);
            }
            else if (currentIndex === 3) {
                this.currentPeriod = new Date().setHours(18, 0, 0, 0);
                this.nextPeriod = new Date().setHours(21, 0, 0, 0);
            }
            else {
                this.currentPeriod = new Date().setHours(21, 0, 0, 0);
                // 创建一个新的 Date 对象
                var tomorrow = new Date();
                // 将日期设置为明天
                tomorrow.setDate(tomorrow.getDate() + 1);
                // 将时间设置为 0点0分0秒
                tomorrow.setHours(0, 0, 0, 0);
                this.nextPeriod = tomorrow
            }
            //获取时间差
            this.currentPeriod = new Date(this.currentPeriod)
            this.currentHour = this.currentPeriod.getHours();
            let diffTime = this.nextPeriod - new Date();
            diffTime /= 1000;
            this.lastHour = parseInt(diffTime / 3600);
            this.lastMinutes = parseInt(diffTime % (3600) / 60);
            this.lastSeconds = parseInt(diffTime % 60);
            //转化时间格式
            this.lastHour = this.lastHour >= 10 ? this.lastHour : '0' + this.lastHour;
            this.lastMinutes = this.lastMinutes >= 10 ? this.lastMinutes : '0' + this.lastMinutes;
            this.lastSeconds = this.lastSeconds >= 10 ? this.lastSeconds : '0' + this.lastSeconds;
        }

    },
    mounted() {
        this.restaurants = this.loadAll();
        this.getTime();
        setInterval(this.getTime, 1000);
        //为秒杀盒子设置吸顶样式
        let top = document.querySelector(".top")
        let advert = document.querySelector(".advert");
        let flash = document.querySelector(".flash");
        window //绑定指定页面滚动区域
            .addEventListener("scroll", function () {
                var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
                if (scrollTop > top.offsetHeight + advert.offsetHeight) {
                    flash.style.position = 'fixed';
                    flash.style.top = "0px";
                    flash.style.right = "99px";
                }
                else {
                    flash.style.position = 'absolute';
                    flash.style.right = "0px";
                }
            });

    }
}
</script>

<style lang="scss" scoped>
@import url("../style/index.css");

.flash {
    position: absolute;
    width: 110px;
    height: 151px;
    right: 0px;
    padding: 10px 0;
    background-image: url(./images/flashBgi.png);
    background-size: contain;

    h5 {
        color: white;
        font-weight: 550;
        line-height: 40px;
        text-align: center;

        span {
            font-size: 16px;
            background-color: #000;
            padding: 2px 3px;
            margin: 0 3px;
        }
    }

    p {
        font-size: 12px;
        margin-top: 40px;
        margin-bottom: 0;
        color: white;
        text-align: center;

        span {
            font-size: 13px;
            font-weight: 550;
        }
    }
}
</style>