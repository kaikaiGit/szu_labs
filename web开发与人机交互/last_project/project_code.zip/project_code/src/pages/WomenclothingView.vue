<template>
    <div class="womenClothing">
        <div class="banner">
            <!-- 头部标题及导航栏 -->
            <div class="header">
                <div class="title">
                    <img src="./images/di10cenglou.png" alt="" />
                    服装鞋包
                </div>
                <!-- 导航栏 -->
                <div class="navtab">
                    <ul>
                        <li><a href="">大牌</a></li>
                        <span class="split"></span>
                        <li><a href="">男装</a></li>
                        <span class="split"></span>
                        <li><a href="">女装</a></li>
                        <span class="split"></span>
                        <li><a href="">鞋靴</a></li>
                        <span class="split"></span>
                        <li><a href="">箱包</a></li>
                        <span class="split"></span>
                        <li><a href="">内衣配饰</a></li>
                        <span class="split"></span>
                        <li><a href="">珠宝首饰</a></li>
                        <span class="split"></span>
                        <li><a href="">奢品礼品</a></li>
                        <span class="split"></span>
                        <li><a href="">奢华腕表</a></li>
                    </ul>
                </div>
            </div>
            <!-- 商品内容 -->
            <div class="content">
                <div class="detail">
                    <!-- 左侧图片 -->
                    <div class="pic">
                        <img src="./images/tu1.png" alt="" />
                        <div class="buttom">
                            <ul>
                                <li>女装新品 品质男鞋</li>
                                <li>服装城 太阳镜</li>
                                <li>时尚女鞋 男装尚新</li>
                                <li>舒适睡衣 奢侈品</li>
                            </ul>
                            <ul>
                                <li>菩提手串 水晶手链</li>
                                <li>时尚女包 精品男包</li>
                                <li>小叶紫檀 奢品名品</li>
                                <li>热销腕表 新品首发</li>
                            </ul>
                        </div>
                    </div>
                    <!-- 商品图及信息 -->
                    <div class="infoList">
                        <div class="info">
                            <img src="./images/di10ceng2.jpg" alt="" />
                            <p class="text">韩都衣舍 夏装新款纯色宽松荷叶袖连衣裙</p>
                            <p class="price">￥159.00</p>
                        </div>
                        <div class="info">
                            <img src="./images/di10ceng3.jpg" alt="" />
                            <p class="text">莫丽菲尔 运动休闲七分袖圆领字母印花连衣裙</p>
                            <p class="price">￥129.00</p>
                        </div>
                        <div class="info">
                            <img src="./images/di10ceng4.jpg" alt="" />
                            <p class="text">妖精的口袋 蕾丝花边拼接条纹雪纺衬衫</p>
                            <p class="price">￥191.20</p>
                        </div>
                        <div class="info">
                            <img src="./images/di10ceng5.jpg" alt="" />
                            <p class="text">Maxchic玛汐 百褶蕾丝袖时尚上衣打底衫</p>
                            <p class="price">￥268.00</p>
                        </div>
                        <div class="info">
                            <img src="./images/di10ceng6.jpg" alt="" />
                            <p class="text">茵曼 长袖连衣裙V领纯棉中长裙</p>
                            <p class="price">￥179.00</p>
                        </div>
                        <div class="info">
                            <img src="./images/di10ceng7.jpg" alt="" />
                            <p class="text">DAZZLE地素 丹宁吊带连衣裙 天兰色</p>
                            <p class="price">￥699.00</p>
                        </div>
                        <div class="info">
                            <img src="./images/di10ceng8.jpg" alt="" />
                            <p class="text">艾格 S休闲牛仔背带半身A字裙 藏青色</p>
                            <p class="price">￥249.00</p>
                        </div>
                        <div class="info">
                            <img src="./images/di10ceng9.jpg" alt="" />
                            <p class="text">Teenie Weenie小熊女装亚麻棉波点休闲衬衫</p>
                            <p class="price">￥598.00</p>
                        </div>
                    </div>
                </div>
                <!-- 下方宣传图 -->
                <div class="nav">
                    <img src="./images/di10ceng10.jpg" alt="" />
                    <img src="./images/di10ceng11.jpg" alt="" />
                    <img src="./images/di10ceng12.jpg" alt="" />
                    <img src="./images/di10ceng13.jpg" alt="" />
                    <img src="./images/di10ceng14.jpg" alt="" />
                </div>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    mounted() {
        let body = document.querySelector("body")
        body.style.backgroundColor = "#f4f4f4"
        let title = document.querySelector("html head title")
        title.innerHTML = "京东女装"
    }
}
</script>

<style scoped>
@import url(../style/womenclothing.css);
</style>