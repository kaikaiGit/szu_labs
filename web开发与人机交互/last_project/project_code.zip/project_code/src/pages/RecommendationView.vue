<template>
    <div>
        <div class="banner">
            <!-- 标题 -->
            <h3>京东·品质生活</h3>
            <!-- 商品内容 -->
            <div class="content">
                <!-- 商品 -->
                <div class="goods">
                    <div class="new_find">
                        <h4>新发现</h4>
                        <div class="big pic">
                            <img src="./images/di9ceng1.jpg" alt="" />
                            <div class="text">
                                <h5>尚新品</h5>
                                <p>乐视轻车机 手机变车机</p>
                                <span>预约抽乐视1S手机</span>
                            </div>
                        </div>
                        <div class="pic">
                            <img src="./images/di9ceng5.jpg" alt="" />
                            <div class="text">
                                <h5>新趋势</h5>
                                <p>便捷航拍无人机</p>
                                <span>送458大礼包</span>
                            </div>
                        </div>
                        <div class="pic">
                            <img src="./images/di9ceng6.jpg" alt="" />
                            <div class="text">
                                <h5>新先购</h5>
                                <p>华为Mate8发售</p>
                                <span>高性能长续航</span>
                            </div>
                        </div>
                    </div>
                    <div class="good_obj">
                        <h4>好物100</h4>
                        <div class="big pic">
                            <img src="./images/di9ceng2.jpg" alt="" />
                            <div class="text">
                                <h5>潮玩好物</h5>
                                <p>愚人节整蛊利器</p>
                                <span>好货低至1元</span>
                            </div>
                        </div>
                        <div class="pic big">
                            <img src="./images/di9ceng7.jpg" alt="" />
                            <div class="text">
                                <h5>潮有范</h5>
                                <p>KAPPA潮人格调</p>
                                <span>G-DRAGON同款</span>
                            </div>
                        </div>
                    </div>
                    <div class="brand_street">
                        <h4>品牌街</h4>
                        <div class="big pic">
                            <img src="./images/di9ceng3.jpg" alt="" />
                            <div class="text">
                                <h5>探寻黑科技</h5>
                                <p>发现之旅</p>
                                <span>iPad Air2 降价了</span>
                            </div>
                        </div>
                        <div class="pic">
                            <img src="./images/di9ceng8.jpg" alt="" />
                            <div class="text">
                                <h5>国际服饰</h5>
                                <p>艾格春夏特惠</p>
                                <span>新品低至5折</span>
                            </div>
                        </div>
                        <div class="pic">
                            <img src="./images/di9ceng9.jpg" alt="" />
                            <div class="text">
                                <h5>科技精品</h5>
                                <p>玩科技</p>
                                <span>空气动力引擎车</span>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- 品牌图 -->
                <div class="brand">
                    <img src="./images/di9ceng4.png" alt="" />
                </div>
            </div>
            <!-- 底部广告 -->
            <div class="advert">
                <img src="./images/di10ceng.png" alt="" />
            </div>
        </div>
    </div>
</template>

<script>
export default {
    mounted() {
        let title = document.querySelector("html head title")
        title.innerHTML = "京东-今日推荐"
    }
}
</script>

<style scoped>
@import url(../style/recommendation.css);
</style>