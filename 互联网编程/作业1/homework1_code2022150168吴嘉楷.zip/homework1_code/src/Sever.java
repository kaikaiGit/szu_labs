//引入相关模块
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
//服务端
public class Sever {
    public static void main(String[] args) throws IOException {
        //创建服务端对象 并 绑定 6666端口
        ServerSocket serverSocket = new ServerSocket(6666);
        //监听等待客户端连接
        Socket socket = serverSocket.accept();
        System.out.println("TCP连接已建立，服务端已就绪！");
        //从socket中获取输入、输出流
        InputStream ins = socket.getInputStream();
        OutputStream os = socket.getOutputStream();
        //创建缓冲流
        BufferedReader reader = new BufferedReader(new InputStreamReader(ins));
        //要发送的文件名
        String fileName = "serverData.txt";
        //读取文件数据
        BufferedReader in = new BufferedReader(new FileReader(fileName));
        String oneLine;
        //逐行读出serverData.txt文件的内容
        while ((oneLine = in.readLine()) != null){
            //逐行发送给客户端
            os.write((oneLine+"\n").getBytes());
        }
        //接收客户端的回应消息并在控制台输出
        while((oneLine = reader.readLine()) != null){
            System.out.println(oneLine);
        }
        //释放socket和服务器资源
        socket.close();
        serverSocket.close();
    }
}