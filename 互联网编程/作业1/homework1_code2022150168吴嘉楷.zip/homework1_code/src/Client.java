//引入相关模块
import java.io.*;
import java.net.Socket;
import java.util.Scanner;
//客户端
public class Client {
    public static void main(String[] args) throws IOException {
        //创建socket对象 并 连接服务端
        Socket socket = new Socket("127.0.0.1",6666);
        //从socket中获取输入、输出流
        InputStream ins = socket.getInputStream();
        OutputStream ous = socket.getOutputStream();
        //将字节流进行转化，以防止 中文乱码 问题，同时，方便读取整行数据
        BufferedReader inReader = new BufferedReader(new InputStreamReader(ins));
        //将接收到的信息保存为ClientData.txt
        String fileName = "ClientData.txt";
        //创建文件输出流用于写文件
        FileWriter fileWriter = new FileWriter(fileName);
        //逐行读取服务器发来的文件内容
        String oneline;
        int index = 1;
        while ((oneline=inReader.readLine()) != null){
            //在控制台中打印
            System.out.println(oneline);
            oneline = (index++) + ":" + oneline + "\n";
            fileWriter.write(oneline);
            fileWriter.flush();
            ous.write(oneline.getBytes());
            if(index==5)break;
        }
        //关闭文件输出流
        fileWriter.close();
        //释放socket资源
        socket.close();
    }
}