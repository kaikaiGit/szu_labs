//服务器日志功能模块

import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;

import java.io.IOException;
public class LogUtil {
    String filePath;
    //通过类名创建Logger对象
    private static final Logger logger = Logger.getLogger(LogUtil.class);

    public LogUtil(String filePath) throws IOException {
        this.filePath = filePath;
        // 配置日志输出格式
        PatternLayout layout = new PatternLayout("%d{yyyy-MM-dd HH:mm:ss} %-5p %c{1}:%L - %m%n");
        // 配置日志文件轮转
        RollingFileAppender appender = new RollingFileAppender();
        appender.setFile(this.filePath);//日志文件路径
        appender.setMaxFileSize("10MB");//文件最大容量
        appender.setMaxBackupIndex(5);//设置轮转文件的最大数量
        appender.setLayout(layout);//日志输出格式
        appender.activateOptions();//激活配置选项
        // 将Appender添加到Logger
        logger.addAppender(appender);
        logger.setLevel(Level.DEBUG); // 设置日志级别为 DEBUG
    }
    //正常日志
    public void logInfo(String message) {
        logger.info(message);
    }
    //报错日志
    public void logError(String message, Throwable t) {
        logger.error(message, t);
    }
}
