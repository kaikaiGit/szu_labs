import java.io.IOException;
//客户端
public class Thread_Client {
    public static void main(String[] args) throws IOException {
        //线程数量，即客户端数量
        int total = 6;
        while(total>0){
            //创建并开启线程
            Thread t = new Thread(new ClientRunnable());
            t.start();
            total--;
        }
    }
}