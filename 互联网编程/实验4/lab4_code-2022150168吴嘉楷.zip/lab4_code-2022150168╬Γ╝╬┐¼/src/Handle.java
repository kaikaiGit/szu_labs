package src;

import java.io.*;
import java.net.Socket ;
import java.util.Scanner;
import java.util.Date;
import java.text.*;
public class Handle implements Runnable {
        private final Socket clientSocket;
        private StringBuilder head = new StringBuilder("");
        private final int pos;
        private FileInputStream fr;
        private BufferedInputStream input;
        private BufferedInputStream in;
        private BufferedOutputStream out;

        public Handle(Socket s, int i) {
            clientSocket = s;
            pos = i;
        }

        public void run() {
            try {
                in = new BufferedInputStream(clientSocket.getInputStream());
                out = new BufferedOutputStream(clientSocket.getOutputStream());
                Scanner sin = new Scanner(in);
                String t;
                while ((t = sin.nextLine()) != null && t.length() != 0) {
                    head.append(t);
                }
                System.out.println(head);
                if (head.toString().startsWith("GET"))
                    doGET();
                else if (head.toString().startsWith("HEAD"))
                    doHEAD();
                else if (head.toString().startsWith("POST"))
                    doPOST();

                String[] head_temp = head.toString().split(" ");
                StringBuilder temp = new StringBuilder("");
                temp.append(head_temp[2] + " 200 OK\r\n");
                Date date = new Date();
                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh : mm : ss");
                temp.append("Set-Cookie: " + pos + " " + dateFormat.format(date) + "\r\n\r\n");
                out.write(temp.toString().getBytes());
                out.flush();
                in.close();

            } catch (IOException e) {
                System.out.println(e);
            }
        }

        public void doGET() throws IOException {
            fr = new FileInputStream("src/resourse/" + head.toString().split(" ")[1]);
            input = new BufferedInputStream(fr);
            byte[] buffer = new byte[4096];
            int len;
            while ((len = input.read(buffer)) > 0) {
                out.write(buffer, 0, len);
                out.flush();
            }
            out.close();
            input.close();
        }

        public void doHEAD() throws IOException {
            String []head_temp=head.toString().split(" ");
            StringBuilder t = new StringBuilder("");
            t.append(head_temp[2]+" 200 OK\r\n");
            Date date = new Date();
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
           t.append("client=" + pos + "; connect_time=" + dateFormat.format(date) + "\r\n");
           t.append("Host:"+clientSocket.getPort());
            t.append("\r\n");
            out.write(t.toString().getBytes());
            out.flush();
            out.close();
        }

        public void doPOST() throws IOException {
            StringBuilder t = new StringBuilder("DOING POST operator now!\nI receive your data!\r\n");
            out.write(t.toString().getBytes());
            out.flush();
            out.close();
        }
    }
