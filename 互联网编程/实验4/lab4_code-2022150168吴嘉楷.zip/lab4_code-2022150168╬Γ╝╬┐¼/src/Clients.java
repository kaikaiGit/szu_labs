package src;

public class Clients {
    public static void main(String []args){
        int n=20;
        for(int i=1;i<=n;i++){
            new Thread(new Client(i)).start();
        }
    }
}
