package first;//引入相关模块
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

//服务端
public class Sever {
    public static void main(String[] args) throws IOException {
        //创建服务端对象 并 绑定 6666端口
        ServerSocket serverSocket = new ServerSocket(6666);

        while (true) {
            //监听等待客户端连接
            Socket socket = serverSocket.accept();
            //开启一条线程
            Thread t = new Thread(new myRunnable(socket));
            t.start();
            //TCP连接已建立
            System.out.println("用户"+t.getName()+"连接上了本服务器！");
        }
    }
}
