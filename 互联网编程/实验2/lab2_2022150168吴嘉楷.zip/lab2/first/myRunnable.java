package first;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;

public class myRunnable implements Runnable{
    Socket socket;
    String name;
    public myRunnable(Socket socket) {
        this.socket = socket;
    }
    @Override
    public void run() {
        this.name = Thread.currentThread().getName();
        try {
            //从socket中获取输入流、输出流
            InputStream ins = socket.getInputStream();
            OutputStream os = socket.getOutputStream();
            //将字节流进行转化，以防止 中文乱码 问题
            InputStreamReader insReader = new InputStreamReader(ins);
            //向客户端发送通知，告知通信连接已建立
            os.write("尊敬的用户，欢迎来到留言墙，小墙墙将耐心倾听您的想法！\n".getBytes());
            //接受客户端发来的消息
            int ch,flag=1;
            while ((ch = insReader.read()) != -1) {
                if(flag==1) System.out.print("用户"+name+"留言：");
                flag = 0; //防止 每接受一个字符就打印一次提示语
                //将依次读取到的字符进行输出
                System.out.print((char)ch);
                if((char)ch == '\n'){ //已接收到一句完整的消息
                    flag = 1; //可以打印提示语
                    //向客户端发送通知
                    os.write("小墙墙已收到了您的留言！\n".getBytes());
                }
            }
            System.out.println("用户"+name+"关闭了通信！");
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if(socket!=null){
                //释放socket和服务器资源
                try {
                    socket.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
