package second;
import java.io.FileWriter;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.*;

//服务端
public class Pool_Sever {
    public static void main(String[] args) throws IOException {
        //创建服务端对象 并 绑定 6666端口
        ServerSocket serverSocket = new ServerSocket(6666);
        //创建线程池对象
        ThreadPoolExecutor pool = new ThreadPoolExecutor(
                3, //核心线程数量
                16, //线程池总大小
                60, //空闲时间
                TimeUnit.SECONDS, //单位
                new ArrayBlockingQueue<>(2), //阻塞队列
                Executors.defaultThreadFactory(), //线程工厂
                new ThreadPoolExecutor.AbortPolicy() //任务拒绝策略
        );
        //创建文件输出流，用于写入安全算法摘要和该通信记录txt文件名
        FileWriter fileWriter = new FileWriter("second/SafeAbstract.txt");
        while (true) {
            //监听等待客户端连接
            Socket socket = serverSocket.accept();
            //把任务题交给线程池
            myRunnable Task = new myRunnable(socket, fileWriter);
            pool.submit(Task);
            //TCP连接已建立
            System.out.println("用户连接上了本服务器！");
        }
    }
}
