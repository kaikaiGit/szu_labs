package second;//引入相关模块
import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class ClientRunnable implements Runnable{
    Socket socket;
    public ClientRunnable() throws IOException {
        //创建socket对象 并 连接服务端
        this.socket = new Socket("127.0.0.1",6666);
        System.out.println("连接已建立，开始读取信源txt文件并发送至服务器...");
    }
    @Override
    public void run() {
        try {
            //创建Scanner对象 以 手动输入数据
            Scanner sc = new Scanner(System.in);
            //从socket中获取输出流、输入流
            OutputStream os = socket.getOutputStream();
            InputStream ins = socket.getInputStream();
            //将字节流进行转化，以防止 中文乱码 问题
            InputStreamReader insReader = new InputStreamReader(ins);
            //从信源txt文件中读取数据，并发送给服务端
            String words, filePath = "second/readData.txt";
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            while( (words=reader.readLine()) != null){ //一次读一整行
                //发送给服务端
                os.write((words+'\n').getBytes());
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            if(socket!=null){
                //释放socket和服务器资源
                try {
                    System.out.println("TCP连接关闭！");
                    socket.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
