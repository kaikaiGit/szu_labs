package second;
import java.io.*;
import java.net.Socket;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class myRunnable implements Runnable{
    Socket socket;
    String name;
    FileWriter safeAbstractWriter;
    static int index = 1;
    public myRunnable(Socket socket, FileWriter fw) {
        this.socket = socket;
        this.safeAbstractWriter = fw;
    }
    @Override
    public void run() {
        this.name = Thread.currentThread().getName();
        try {
            //从socket中获取输入流、输出流
            InputStream ins = socket.getInputStream();
            OutputStream os = socket.getOutputStream();
            //将字节流进行转化,以便于一次读写一行数据
            BufferedReader reader = new BufferedReader(new InputStreamReader(ins));
            //接受客户端发来的消息
            String words;
            //创建文件输入流
            String fileRoot = "second/txtFiles/";
            String fileName = "tcpContent_of_poolThread" + index++ + ".txt";
            String filePath = fileRoot + fileName;
            FileWriter fileWriter = new FileWriter(filePath);
            while ((words = reader.readLine()) != null) {
                //追加至相应文件中
                fileWriter.append(words+"\n");
            }
            fileWriter.flush();
            fileWriter.close();
            //计算文件的安全算法摘要
            FileInputStream in = new FileInputStream(filePath);
            MessageDigest sha = MessageDigest.getInstance("SHA-256");
            DigestInputStream din = new DigestInputStream(in,sha);
            while(din.read()!=-1);
            din.close();
            //将安全算法摘要和该通信记录txt文件名一起写入SafeAbstract.txt中
            safeAbstractWriter.write("文件名："+fileName+"\n安全算法摘要："+sha.digest()+"\n\n");
            safeAbstractWriter.flush();
        } catch (IOException | NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        } finally {
            if(socket!=null){
                //释放socket和服务器资源
                try {
                    socket.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
}
