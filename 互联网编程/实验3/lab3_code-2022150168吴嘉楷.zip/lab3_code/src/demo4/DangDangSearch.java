package demo4;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Scanner;
public class DangDangSearch {
    public static void main(String[] args) throws IOException {
        // 用户输入商品搜索关键词
        Scanner scanner = new Scanner(System.in);
        System.out.print("请输入您要搜索的内容：");
        String keyword = scanner.nextLine();
        keyword = URLEncoder.encode(keyword,"gbk");//防止乱码
        // 构建搜索 URL
        String searchUrl = "http://search.dangdang.com/?key=" + keyword;
        // 建立url连接 并 获取HTML源代码
        String htmlContent = getHtmlContent(searchUrl);
        // 输出HTML源代码到控制台
        System.out.println(htmlContent);
        // 将HTML源代码保存到文件productResult.html中
        saveHtmlToFile(htmlContent, "src/demo4/productResult.html");
    }
    private static String getHtmlContent(String url) throws IOException {
        // 建立连接
        URLConnection connection = new URL(url).openConnection();
        //获取url连接的字节流，创建缓冲流对象
        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        //获取 HTML 源代码
        StringBuilder content = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            content.append(line);
            content.append("\n");
        }
        reader.close();
        return content.toString();
    }
    private static void saveHtmlToFile(String htmlContent, String fileName) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(fileName));
        writer.write(htmlContent);
        System.out.println("搜索结果已保存到 " + fileName);
    }
}
