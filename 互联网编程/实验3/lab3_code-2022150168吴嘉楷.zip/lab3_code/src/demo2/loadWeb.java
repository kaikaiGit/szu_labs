//功能：下载一个web页面
package demo2;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.Scanner;

public class loadWeb {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        //用户输入一个url网址
        System.out.print("请输入您要下载的Web页面的url：");
        String urlString = sc.next();
        //创建 URL 对象
        URL url = new URL(urlString);
        //打开url连接
        URLConnection connection = url.openConnection();
        //获取url连接的字节流，创建缓冲流对象
        BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        //读取网页内容
        StringBuilder content = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            content.append(line);
            content.append("\n");
        }
        reader.close();
        // 在控制台显示网页内容
        System.out.println("网页内容：");
        System.out.println(content);
        // 将网页内容保存为文件
        String filePath = "src/demo2/webpage.html/";//文件路径
        FileWriter fileWriter = new FileWriter(filePath);
        fileWriter.write(content.toString());
        fileWriter.close();
        System.out.println("网页已保存至 " + filePath);
    }
}
