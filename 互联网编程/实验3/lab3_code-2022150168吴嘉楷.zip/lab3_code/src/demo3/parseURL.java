//功能：分析URL的各组成部分
package demo3;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class parseURL {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        // 获取用户输入的 URL
        System.out.print("请输入您要分析的url：");
        String urlString = sc.next();
        // 创建 URL 对象
        URL url = new URL(urlString);
        // 输出各组成部分
        System.out.println("协议Protocol: " + url.getProtocol());
        System.out.println("域名Authority: " + url.getAuthority());
        System.out.println("主机Host: " + url.getHost());
        System.out.println("端口Port: " + url.getPort());
        System.out.println("默认端口号: " + url.getDefaultPort());
        System.out.println("路径Path: " + url.getPath());
        System.out.println("内容Content: " + url.getContent());
    }
}
