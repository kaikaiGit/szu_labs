package demo1;

import java.net.UnknownHostException;

public class test {
    public static void main(String[] args) throws UnknownHostException {
        //创建DNS解析服务对象
        myDNS dns = new myDNS();
        //调用域名解析为IP的服务
        String IP = dns.nameToIP();
        //打印解析出的IP
        System.out.println("该域名对应的IP地址为：" + IP);
        //调用IP解析为域名的服务
        String name = dns.IPtoName();
        ///打印出解析出的域名
        System.out.println("该IP地址对应的域名为：" + name);
    }
}
