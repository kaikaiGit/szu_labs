//可重用的域名解析程序模块
package demo1;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Scanner;

public class myDNS {
    Scanner sc = new Scanner(System.in);
    //将用户输入的域名解析为IP地址
    public String nameToIP() throws UnknownHostException {
        //接收用户输入的域名
        System.out.print("请输入您要解析的域名：");
        String hostName =  sc.next();
        //根据域名获取address
        InetAddress address = InetAddress.getByName(hostName);
        //返回address的IP
        return address.getHostAddress();
    }
    //将用户输入的IP地址，反向解析为对应的主机名或域名
    public String IPtoName() throws UnknownHostException {
        //接收用户输入的IP
        System.out.print("请输入您要解析的IP：");
        String IP =  sc.next();
        //根据IP获取address
        InetAddress address = InetAddress.getByName(IP);
        //返回address的域名
        return address.getHostName();
    }
}
